# Exercise 1: Variables and Data Types

width = 640
height = 480
image_name = "sample.png"
is_color = True

print("Width:", width, type(width))
print("Height:", height, type(height))
print("Image Name:", image_name, type(image_name))
print("Is Color:", is_color, type(is_color))

total_pixels = width * height
print("Total Pixels:", total_pixels)



# Exercise 2: if, elif, and else

intensities = [-1, 0, 127, 128, 255, 256]

for intensity in intensities:
    if intensity < 0 or intensity > 255:
        label = "Invalid"
    elif intensity >= 128:
        label = "Bright pixel"
    else:
        label = "Dark pixel"

    print("Intensity:", intensity, "| Label:", label)


    
# Exercise 3: for and while Loops

pixel_values = [20, 130, 255]

for pixel in pixel_values:
    if pixel >= 128:
        label = "Bright pixel"
    else:
        label = "Dark pixel"

    print("Pixel:", pixel, "| Label:", label)

count = 0
while count < 3:
    print("Count:", count)
    count += 1



# Exercise 4: Functions

def is_bright(pixel, threshold=128):
    if pixel >= threshold:
        return True
    else:
        return False

print("is_bright(127):", is_bright(127))
print("is_bright(128):", is_bright(128))
print("is_bright(200, 210):", is_bright(200, 210))




# Exercise 5: Lists and Tuples

# Lists are mutable, but tuples are immutable.
# List items can be changed, but tuple items cannot.

pixels = [0, 128, 255]

print("First pixel:", pixels[0])

pixels[1] = 150
pixels.append(64)

print("Updated pixels:", pixels)
print("Length:", len(pixels))

size = (640, 480)
width, height = size

print("Width:", width)
print("Height:", height)



# Exercise 6: Dictionaries and Sets

image = {"width": 640, "height": 480}
image["mode"] = "RGB"

print("Image Width:", image["width"])
print("Image Mode:", image["mode"])

labels = ["cat", "dog", "cat", "bird"]
unique_labels = set(labels)

print("Unique Labels:", len(unique_labels))




import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
